function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Laboratorio Cuántico · Lectura Bio-Well')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName('Pacientes');
  if (!sh) {
    sh = ss.insertSheet('Pacientes');
    sh.appendRow([
      'Registro','Fecha','Nombre','Email','Archivo',
      'Campo J ×10^-2','Estrés','Chakras %','Reserva %',
      'Actividad física %','Nutrición %','Ambiente %',
      'Psicología %','Sueño %','Hormonas %','Conclusión'
    ]);
    sh.setFrozenRows(1);
  }
  return sh;
}

function guardarPaciente(data) {
  const sh = setup();
  const registro = 'LQ-' + Utilities.formatDate(
    new Date(), Session.getScriptTimeZone(), 'yyyyMMdd-HHmmss'
  );

  sh.appendRow([
    registro, new Date(),
    data.nombre || '', data.email || '', data.archivo || '',
    data.campo || '', data.estres || '', data.chakras || '', data.reserva || '',
    data.fisica || '', data.nutricion || '', data.ambiente || '',
    data.psicologia || '', data.sueno || '', data.hormonas || '',
    data.conclusion || ''
  ]);

  return registro;
}

function enviarInforme(data) {
  if (!data.email) throw new Error('Falta email.');
  const registro = guardarPaciente(data);

  const nombre = escapeHtml(data.nombre || 'Participante');
  const body =
    '<p>Hola ' + nombre + ',</p>' +
    '<p>Te compartimos tu devolución de lectura de Laboratorio Cuántico.</p>' +
    '<p><b>Número de registro:</b> ' + escapeHtml(registro) + '</p>' +
    '<p>La devolución presenta los parámetros disponibles de la medición como una fotografía orientativa del momento. No constituye un diagnóstico médico.</p>' +
    '<p>Laboratorio Cuántico</p>';

  GmailApp.sendEmail(
    data.email,
    'Tu lectura · Laboratorio Cuántico',
    stripHtml(body),
    {htmlBody: body, name: 'Laboratorio Cuántico'}
  );

  return registro;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, function(m) {
    return {
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
    }[m];
  });
}

function stripHtml(s) {
  return s.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}