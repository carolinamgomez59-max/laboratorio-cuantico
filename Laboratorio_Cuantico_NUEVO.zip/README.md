# LABORATORIO CUÁNTICO — versión nueva

## Qué hace
- Una persona por vez.
- Carga un PDF individual de Bio-Well.
- Intenta extraer texto y, si el PDF es una imagen/escaneo, activa OCR en el navegador.
- Detecta los parámetros principales:
  - Campo energético
  - Nivel de estrés
  - Alineación de chakras
  - Reserva de energía
  - Esferas de estilo de vida cuando aparecen en el informe
- Permite revisar y corregir los valores antes de generar la devolución.
- Genera una devolución visual propia de Laboratorio Cuántico.
- Permite guardar el registro en Google Sheets.
- Permite enviar un email desde la cuenta autorizada de Google Apps Script.
- Permite imprimir/guardar la devolución como PDF.

## Base del diseño
La referencia visual se tomó de los materiales Bio-Well mostrados en esta conversación, incluyendo el informe individual y el mapa energético familiar. La versión de Laboratorio Cuántico NO intenta copiar el informe original: organiza los datos en una devolución propia, simple y orientativa.

## Importante
Bio-Well presenta sus mediciones como análisis de energía/estrés y no como diagnóstico médico. La devolución de Laboratorio Cuántico mantiene esa limitación: no diagnostica, no promete resultados y no establece causalidades médicas.

## Instalación en Google Apps Script

1. Crear un proyecto nuevo en Google Apps Script.
2. Crear un archivo HTML llamado exactamente `Index`.
3. Crear un archivo de script llamado `Code`.
4. Copiar `Index.html` en `Index`.
5. Copiar `Code.gs` en `Code`.
6. En el proyecto, elegir una función y ejecutar `setup()` una vez.
7. Autorizar los permisos solicitados para Sheets y Gmail.
8. Ir a Implementar → Nueva implementación → Aplicación web.
9. Ejecutar como: tú.
10. Acceso: según el público que vaya a utilizarlo.
11. Abrir la URL de la aplicación.

## Google Sheets
El sistema crea una hoja llamada `Pacientes` con los registros.

## Seguridad
No se guardan datos personales dentro de GitHub. Los datos enviados al backend quedan en la hoja de cálculo vinculada al proyecto de Apps Script.

## Nota sobre OCR
El OCR corre en el navegador mediante Tesseract.js. La primera lectura de un PDF con muchas páginas puede tardar. Por eso se muestra una barra de progreso.

## Siguiente etapa
Después de probar esta versión con varios PDFs reales, conviene ajustar las expresiones de detección a los formatos exactos que entregue Bio-Well en los informes que ustedes reciban.
